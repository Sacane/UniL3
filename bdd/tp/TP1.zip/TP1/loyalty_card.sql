DROP TRIGGER IF EXISTS loyalty_trigger ON contient;

CREATE OR REPLACE FUNCTION update_loyalty()
RETURNS TRIGGER AS 
$$
    DECLARE 
    pts int;
    fac facture%ROWTYPE;
    loyalty fidelite%ROWTYPE;


    BEGIN
        pts = NEW.prixUnit * NEW.quantite;
        SELECT * into fac FROM facture WHERE idfac = NEW.idfac;
        SELECT * into loyalty FROM fidelite WHERE numcli = fac.numcli AND idmag = fac.idmag;
        IF NOT FOUND THEN 
            RAISE NOTICE 'Dommage ! Vous n avez pas de cartes de fidelité, vous auriez pu quand meme gagner % points :))))', pts;
            RETURN NULL;

        END IF;
        
        RAISE NOTICE 'Vous avez gagné % points !', pts;
        UPDATE fidelite SET points = points + pts WHERE idmag = fac.idmag AND fac.numcli = numcli;

        RETURN NEW;
    END;
$$
language plpgsql;


CREATE TRIGGER loyalty_trigger
AFTER UPDATE OR INSERT ON contient
FOR EACH ROW 
EXECUTE PROCEDURE update_loyalty();


-- INSERT INTO contient VALUES (DEFAULT, 77, 10, 5);