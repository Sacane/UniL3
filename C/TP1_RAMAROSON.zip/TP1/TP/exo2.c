#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int bin(int n, int p){
    assert(p <= n);
    assert(n > 0);
    if(p == 0 || n == p){
        return 1;
    }
    return bin(n - 1, p) + bin(n - 1, p - 1);
}

/**
 * W: Use allocation memory
 */  
int **binTab(int n, int p){
    int i, j, **tab;

    tab = malloc(sizeof(int**) * n);
    for(i = 0; i < n; i++){
        tab[i] = malloc(sizeof(int*) * p);
        tab[i][0] = 1;
        for(j = 0; j < p; j++){
            tab[i][j] = tab[i-1][j] + tab[i-1][j-1];
        }
    }

    return tab;
}

int main(int argc, char const *argv[])
{
    int **tab, n, p, i, j;
    n = 3;
    p = 5;
    printf("1 : %d\n", bin(n, p));
    tab = binTab(n, p);
    for(i = 0; i < n; i++){
        for(j = 0; j < p; j++){
            free(tab[i][j]);
        }
    }
    return 0;
}
