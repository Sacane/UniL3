#include <stdio.h>
#include <stdlib.h>


int pgcd(){
    
}

int main(int argc, char const *argv[])
{
    /* code */
    return 0;
}
