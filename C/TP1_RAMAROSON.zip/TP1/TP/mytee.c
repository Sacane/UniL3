#include <stdlib.h>
#include <stdio.h>
#include <assert.h>


#define SIZE 1024

int main(int argc, char const *argv[])
{
    assert(argc > 1);

    char keyRead[SIZE];

    FILE *f = fopen(argv[1], "w");
    assert(f != NULL);
    while((fgets(keyRead, SIZE, stdin) != NULL)){
        printf("%s", keyRead);
        fprintf(f, "%s",keyRead);
    }

    fclose(f);
    return 0;
}
