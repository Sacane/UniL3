#ifndef SEM_PARSER__H
#define SEM_PARSER__H


#include "table-parser.h"


int parseSemError(Node *node, List table);


#endif