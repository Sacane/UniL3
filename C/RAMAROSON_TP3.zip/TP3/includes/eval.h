#ifndef __EVAL
#define __EVAL

#include "stack.h"
#include "operator.h"

int eval(Stack *st, char operator);


#endif