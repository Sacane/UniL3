#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Implémentation d'un graphe non orienté à l'aide d'un dictionnaire: les clés
sont les sommets, et les valeurs sont les sommets adjacents à un sommet donné.
Les boucles sont autorisées. Les poids ne sont pas autorisés.

On utilise la représentation la plus simple: une arête {u, v} sera présente
deux fois dans le dictionnaire: v est dans l'ensemble des voisins de u, et u
est dans l'ensemble des voisins de v.
"""


class Graphe(object):
    def __init__(self):
        """Initialise un graphe sans arcs"""
        self.dictionnaire = dict()
        self.coordonnees = dict()

    def ajouter_arc(self, u, v, capacite):
        """Ajoute un arc entre les sommmets u et v, en créant les sommets
        manquants le cas échéant."""
        # vérification de l'existence de u et v, et création(s) sinon
        if u not in self.dictionnaire:
            self.dictionnaire[u] = set()
        if v not in self.dictionnaire:
            self.dictionnaire[v] = set()
        self.dictionnaire[u].add((v, capacite))

    def ajouter_arcs(self, iterable):
        """Ajoute tous les arcs de l'itérable donné au graphe. N'importe
        quel type d'itérable est acceptable, mais il faut qu'il ne contienne
        que des couples d'éléments (quel que soit le type du couple)."""
        for u, v, flot in iterable:
            self.ajouter_arc(u, v, flot)

    def ajouter_sommet(self, sommet, coords):
        """Ajoute un sommet (de n'importe quel type hashable) au graphe."""
        self.dictionnaire[sommet] = set()
        self.coordonnees[sommet] = coords

    def ajouter_sommets(self, iterable):
        """Ajoute tous les sommets de l'itérable donné au graphe. N'importe
        quel type d'itérable est acceptable, mais il faut qu'il ne contienne
        que des éléments hashables."""
        for sommet, coords in iterable:
            self.ajouter_sommet(sommet, coords)

    def arcs(self):
        """Renvoie l'ensemble des arcs du graphe. Un arc est représenté
        par un tuple (a, b) avec a <= b afin de permettre le renvoi de boucles.
        """
        return {
            (u, v, flot) for u in self.dictionnaire
            for v, flot in self.dictionnaire[u]
        }

    def poids_arc(self, u, v):
        """Renvoie le poids d'un arc de notre graphe"""
        for sommet, flot in self.dictionnaire[u]:
            if sommet == v:
                return flot

    def boucles(self):
        """Renvoie les boucles du graphe, c'est-à-dire les arcs reliant un
        sommet à lui-même."""
        return {(u, v, flot) for u in self.dictionnaire for v, flot in self.dictionnaire[u] if u == v}

    def contient_arc(self, u, v):
        """Renvoie True si l'arête {u, v} existe, False sinon."""
        if self.contient_sommet(u) and self.contient_sommet(v):
            for sommet, flot in self.dictionnaire[u]:
                if sommet == v:
                    return True
        return False

    def contient_sommet(self, u):
        """Renvoie True si le sommet u existe, False sinon."""
        return u in self.dictionnaire

    def degre(self, sommet):  # A vérifier (degré entrant ou sortant) ici sortant
        """Renvoie le nombre de voisins du sommet; s'il n'existe pas, provoque
        une erreur."""
        return len(self.dictionnaire[sommet])

    def nombre_arcs(self):
        """Renvoie le nombre d'arcs du graphe."""
        return len(self.arcs())

    def nombre_boucles(self):
        """Renvoie le nombre d'arcs de la forme {u, u}."""
        return len(self.boucles())

    def nombre_sommets(self):
        """Renvoie le nombre de sommets du graphe."""
        return len(self.dictionnaire)

    def retirer_arc(self, u, v):
        """Retire l'arc {u, v} s'il existe."""
        suppr = 0
        for sommet, flot in self.dictionnaire[u]:
            if sommet == v:
                flot_a_supprimer = flot
                suppr = 1

        if suppr == 1:
            self.dictionnaire[u].remove((v, flot_a_supprimer))

    def retirer_arcs(self, iterable):
        """Retire tous les arcs de l'itérable donné du graphe. N'importe
        quel type d'itérable est acceptable, mais il faut qu'il ne contienne
        que des couples d'éléments (quel que soit le type du couple)."""
        for u, v in iterable:
            self.retirer_arc(u, v)

    def retirer_sommet(self, sommet):
        """Efface le sommet du graphe, et retire tous les arcs qui lui
        sont incidents."""
        del self.dictionnaire[sommet]
        # retirer le sommet des ensembles de voisins
        for u in self.dictionnaire:
            self.retirer_arc(u, sommet)

    def retirer_sommets(self, iterable):
        """Efface les sommets de l'itérable donné du graphe, et retire tous
        les arcs incidents à ces sommets."""
        for sommet in iterable:
            self.retirer_sommet(sommet)

    def sommets(self):
        """Renvoie l'ensemble des sommets du graphe."""
        return set(self.dictionnaire.keys())

    def sous_graphe_induit(self, iterable):
        """Renvoie le sous-graphe induit par l'itérable de sommets donné."""
        G = Graphe()
        G.ajouter_sommets(iterable)
        for u, v, flot in self.arcs():
            if G.contient_sommet(u) and G.contient_sommet(v):
                G.ajouter_arc(u, v, flot)
        return G

    def voisins(self, sommet):
        """Renvoie l'ensemble des voisins du sommet donné."""
        return {u for u, flot in self.dictionnaire[sommet]}

    def sources(self):
        """Renvoie l'ensemble des sources du graphe"""
        sources = []
        for u in self.dictionnaire:
            arete_entrante = 0
            for v in self.dictionnaire:
                if self.contient_arc(v, u):
                    arete_entrante += 1
            if arete_entrante == 0:
                sources.append(u)
        return sources

    def puits(self):
        """Renvoie l'ensemble des puits du graphe"""
        puits = []
        for u in self.sommets():
            if self.degre(u) == 0:
                puits.append(u)
        return puits