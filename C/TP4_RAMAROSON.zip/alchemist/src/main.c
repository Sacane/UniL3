#include <stdio.h>
#include <stdlib.h>

#include "../includes/test.h"

int main(int argc, char const *argv[])
{

    test_controller();
    return 0;
}
