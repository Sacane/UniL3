#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 16:14:58 2022

@author: quentin - Johan
"""

from graphe import *
import copy
from itertools import *
import math


def augmenter_flot(f, P):
    capacite_min = None
    counter = 0
    for _, _, capacite in P.arcs():
        if capacite_min is None or capacite < capacite_min:
            capacite_min = capacite
            counter += 1

    for u, v, c in P.arcs():
        if (u, v) in f:
            f[(u, v)] = f[(u, v)] + capacite_min
        else:
            f[(v, u)] = f[(v, u)] - capacite_min


def mettre_a_jour_residuel(G, G_residuel, arcs, f):
    cf = dict()
    for u, v, c in arcs:
        cf[(u, v)] = 0
        cf[(v, u)] = 0

    for u, v, c in arcs:
        if G.contient_arc(v, u):
            tmp = u
            u = v
            v = tmp
        cf[(u, v)] = G.poids_arc(u, v) - f[(u, v)]
        cf[(v, u)] = f[(u, v)]

    for u, v, c in arcs:
        if cf[(u, v)] > 0:
            G_residuel.ajouter_arc(u, v, cf[(u, v)])
        else:
            G_residuel.retirer_arc(u, v)


def reconstruire_chemin(G, debut, fin, parents):
    chemin = Graphe()
    v = fin
    while v != debut:
        if parents[v] is None:
            return None
        chemin.ajouter_arc(parents[v], v, G.poids_arc(parents[v], v))
        v = parents[v]
    return chemin


def chemin_augmentant(G, source, puits):
    deja_visites = dict()
    a_traiter = [source]
    parents = dict()
    for sommet in G.sommets():
        deja_visites[sommet] = False
        parents[sommet] = None
    while len(a_traiter) > 0:
        sommet = a_traiter.pop(0)
        if sommet == puits:
            break
        if not deja_visites[sommet]:
            deja_visites[sommet] = True
            for suivant in G.voisins(sommet):
                a_traiter.append(suivant)
                if parents[suivant] is None:
                    parents[suivant] = sommet
    return reconstruire_chemin(G, source, puits, parents)


def flot_maximum(graphe):
    graphe_cpy = copy.deepcopy(graphe)
    valeur = 0
    flot = dict()
    for u, v, c in graphe_cpy.arcs():
        flot[(u, v)] = 0
    source = graphe_cpy.sources()[0]
    puits = graphe_cpy.puits()[0]
    Gf = graphe_cpy
    chemin = chemin_augmentant(graphe_cpy, source, puits)
    while chemin is not None:
        augmenter_flot(flot, chemin)
        mettre_a_jour_residuel(graphe_cpy, Gf, chemin.arcs(), flot)
        chemin = chemin_augmentant(Gf, source, puits)
    for elem in flot:
        if elem[0] == source:
            valeur += flot[elem]
    return valeur, flot


def reseau_residuel(reseau, flot):
    Gf = Graphe()
    for u, v in flot:
        if reseau.poids_arc(u, v) - flot[(u, v)] > 0:
            Gf.ajouter_arc(u, v, reseau.poids_arc(u, v) - flot[(u, v)])
        if flot[(u, v)] > 0:
            Gf.ajouter_arc(v, u, flot[(u, v)])
    return Gf


def coupe_minimum(residuel, sources):
    deja_visites = dict()
    for sommet in residuel.sommets():
        deja_visites[sommet] = False
    a_traiter = []
    coupe = dict()
    coupe['sources'] = set()
    coupe['puits'] = set()
    for u in sources:
        a_traiter.append(u)
    while len(a_traiter) > 0:
        sommet = a_traiter.pop()
        deja_visites[sommet] = True
        if sommet not in coupe['sources']:
            coupe['sources'].add(sommet)
        for v in residuel.voisins(sommet):
            if not deja_visites[v]:
                a_traiter.append(v)
    for u in residuel.sommets():
        if u not in coupe['sources']:
            coupe['puits'].add(u)

    return list(coupe['sources']), list(coupe['puits'])


def augmentations_uniques_utiles(G: Graphe, flot_max):
    # Algo:
    # On récupère l'ensemble des arcs du graphe en O(|V|) et on parcours le dico de flot max
    # Si le flot de l'arc est égale à celle du flot_maximum, on l'ajoute alors a la liste à retourner
    arcs = G.arcs()
    return [(s, t) for s, t, f in arcs if flot_max[(s, t)] == f]


def augmentations_uniques_utiles_calibrees(G: Graphe, flot_max):
    useful_augments = augmentations_uniques_utiles(G, flot_max)
    calibrated = dict()
    before = dict()
    for u, v in useful_augments:
        G_prime = Graphe()
        for (s, t, f) in G.arcs():
            before[(s, t)] = f
            capacite = float('inf') if s == u and v == t else f
            G_prime.ajouter_arc(s, t, capacite)
        value, new_max_flot = flot_maximum(G_prime)
        res = new_max_flot[(u, v)] - before[(u, v)]
        if res > 0:
            calibrated[(u, v)] = res
    return calibrated


def ensemble_minimum_augmentations_utiles_calibrees(G: Graphe, flot_max, cible=1):
    print('Beginning of the function')
    target = cible
    res = dict()
    calibrated_augments = (augmentations_uniques_utiles_calibrees(G, flot_max))
    print(calibrated_augments)
    for element in calibrated_augments:
        if cible == element[1]:
            res[element[0]] = flot_max[element[0]] + element[1]
            return res
    to_treat = set(calibrated_augments)
    print(to_treat)
    G_prime = Graphe()
    arc = ()

    iter = max(to_treat, key=lambda p: p[1])
    print(iter)
    for (s, t, f) in G.arcs():
        capacite = calibrated_augments[iter] + f if (s, t) in to_treat else f
        G_prime.ajouter_arc(s, t, capacite)
    value, new_max_flot = flot_maximum(G_prime)

    print(arc)
    print('G arcs')
    print(sorted(G.arcs()))
    print('G_prime arc :')
    print(sorted(G_prime.arcs()))
    print('nouveau flot max :')
    print(sorted(new_max_flot.items()))

    #TODO
    print('end function return :' + res.items().__str__())
    return res


def rajouts_uniques_utiles(graphe, flot_max):
    flot = None
    flot_tmp = None
    flot_prec_u = 0
    flot_v_suiv = 0
    capacite_tmp = 0
    capacite_prec_u = 0
    capacite_v_suiv = 0
    res = []
    a_traiter = []
    sommet = None

    for u in graphe.sommets():
        for v in graphe.sommets():
            if not graphe.contient_arc(u, v) and not graphe.contient_arc(v, u) and u not in graphe.puits() and v not in graphe.sources() and u != v:
                for a, b in flot_max:
                    if b == u:
                        flot_prec_u += flot_max[(a, u)]
                        capacite_prec_u += graphe.poids_arc(a, u)
                    if a == v:
                        flot_v_suiv += flot_max[(v, b)]
                        capacite_v_suiv += graphe.poids_arc(v, b)
                if v in graphe.puits():
                    if u in graphe.sources():
                        res.append((u, v, math.sqrt((graphe.coordonnees[v][0] - graphe.coordonnees[u][0]) ** 2 + (graphe.coordonnees[v][1] - graphe.coordonnees[u][1]) ** 2), 10000))
                    else:
                        res.append((u, v, math.sqrt((graphe.coordonnees[v][0] - graphe.coordonnees[u][0]) ** 2 + (graphe.coordonnees[v][1] - graphe.coordonnees[u][1]) ** 2), capacite_prec_u - flot_prec_u))
                if (flot_prec_u < capacite_prec_u or u in graphe.sources()) and v not in graphe.puits():
                    puit = graphe.puits()[0]
                    graphe_cpy = copy.deepcopy(graphe)
                    chemin = chemin_augmentant(graphe_cpy, v, puit)
                    while(chemin != None):
                        sommet = v
                        while sommet != 't':
                            for prochain in chemin.dictionnaire[sommet]:
                                if flot_tmp == None or graphe_cpy.poids_arc(sommet, prochain[0]) - flot_max[(sommet, prochain[0])] < flot_tmp:
                                    flot_tmp = graphe_cpy.poids_arc(sommet, prochain[0]) - flot_max[(sommet, prochain[0])]
                                if prochain[0] == puit:
                                    graphe_cpy.retirer_arc(sommet, prochain[0])
                                sommet = prochain[0]
                        if flot == None or flot_tmp > flot:
                            flot = flot_tmp
                        flot_tmp = None
                        chemin = chemin_augmentant(graphe_cpy, v, puit)
                    if flot != 0:
                        if u in graphe.sources():
                            res.append((u, v, math.sqrt((graphe.coordonnees[v][0] - graphe.coordonnees[u][0]) ** 2 + (graphe.coordonnees[v][1] - graphe.coordonnees[u][1]) ** 2), flot))
                        else:
                            res.append((u, v, math.sqrt((graphe.coordonnees[v][0] - graphe.coordonnees[u][0]) ** 2 + (graphe.coordonnees[v][1] - graphe.coordonnees[u][1]) ** 2), min(capacite_prec_u - flot_prec_u, flot)))
                flot = None
                flot_tmp = None
                flot_prec_u = 0
                flot_v_suiv = 0
                capacite_tmp = 0
                capacite_prec_u = 0
                capacite_v_suiv = 0
                a_traiter = []
                sommet = None
    return res


def all_combinations(lst):
    s = list(lst)
    return chain.from_iterable(combinations(s, r) for r in range(1, len(s) + 1))


def ensemble_optimal_rajouts(graphe, flot_max, budget):
    longueur_totale = 0
    meilleur_ajout_flot = 0
    ajout_flot = 0
    res = dict()
    ajout_possible = rajouts_uniques_utiles(graphe, flot_max)

    for x in all_combinations(ajout_possible):
        for u, v, longueur, augmentation in x:
            longueur_totale += longueur
            ajout_flot += augmentation
        if longueur_totale <= budget and ajout_flot > meilleur_ajout_flot:
            meilleur_ajout_flot = ajout_flot
            res = dict()
            for u, v, longueur, augmentation in x:
                res[(u, v)] = augmentation
        longueur_totale = 0
        ajout_flot = 0

    return res


# S = Graphe()
# S.ajouter_arc('s', 'a', 16)
# S.ajouter_arc('s', 'b', 13)
# S.ajouter_arc('b', 'a', 4)
# S.ajouter_arc('a', 'c', 12)
# S.ajouter_arc('b', 'd', 14)
# S.ajouter_arc('c', 'b', 9)
# S.ajouter_arc('d', 'c', 7)
# S.ajouter_arc('c', 't', 20)
# S.ajouter_arc('d', 't', 4)
#
# (val, flot) = flot_maximum(S)
# print((val, flot))
# S_residuel = reseau_residuel(S, flot)
# print("residuel : ")
# print(S_residuel.dictionnaire)
# print('coupe minimum')
# print(coupe_minimum(S_residuel, S.sources()))
#
# # ==============================
#
# G = Graphe()
# G.ajouter_arc('s', 'a', 16)
# G.ajouter_arc('s', 'b', 13)
# G.ajouter_arc('a', 'b', 10)
#
# print(flot_maximum(G))
#
# S = Graphe()
# S.ajouter_arc('s', 'a', 16)
# S.ajouter_arc('s', 'b', 13)
# S.ajouter_arc('b', 'a', 4)
# S.ajouter_arc('a', 'c', 12)
# S.ajouter_arc('b', 'd', 14)
# S.ajouter_arc('c', 'b', 9)
# S.ajouter_arc('d', 'c', 7)
# S.ajouter_arc('c', 't', 20)
# S.ajouter_arc('d', 't', 4)
#
# print(flot_maximum(S))
#
# # ===========================
#
# Gp = Graphe()
#
# for u, v, c in [('s', 'a', 4), ('s', 'b', 4), ('a', 'd', 1), ('a', 'c', 3), ('b', 'c', 3), ('b', 'e', 1), ('c', 't', 2),
#                 ('d', 't', 2), ('e', 't', 4)]:
#     Gp.ajouter_arc(u, v, c)
#
# flot = {('s', 'a'): 2, ('s', 'b'): 2, ('a', 'd'): 1, ('a', 'c'): 1, ('b', 'c'): 1, ('b', 'e'): 1, ('c', 't'): 2,
#         ('d', 't'): 1, ('e', 't'): 1}
# print("Augmentation uniques utiles : ")
# print(sorted(augmentations_uniques_utiles(Gp, flot)))
# print("Augmentation calibrées :")
# print(sorted(augmentations_uniques_utiles_calibrees(Gp, flot).items()))
#
# G = Graphe()
# for sommet, coordonnees in [("s", (0, 0)), ("a", (1.5, 1)), ("b", (1.5, -1)), ("c", (3, 0)), ("d", (4.5, 1)), ("e", (4.5, -1)), ("t", (6, 0))]: G.ajouter_sommet(sommet, coords=coordonnees)
# for u, v, c in [('s', 'a', 4), ('s', 'b', 4), ('a', 'd', 1), ('a', 'c', 3), ('b', 'c', 3), ('b', 'e', 1), ('c', 't', 2), ('d', 't', 2), ('e', 't', 4)]: G.ajouter_arc(u, v, capacite=c)
# flot = {('s', 'a'): 2, ('s', 'b'): 2, ('a', 'd'): 1, ('a', 'c'): 1, ('b', 'c'): 1, ('b', 'e'): 1, ('c', 't'): 2, ('d', 't'): 1, ('e', 't'): 1}
# print(sorted(rajouts_uniques_utiles(G, flot)))

G = Graphe()

for u, v, c in [('s', 'a', 4), ('s', 'b', 4), ('a', 'd', 1), ('a', 'c', 1), ('b', 'c', 3), ('b', 'e', 1), ('c', 't', 2),
                ('d', 't', 2), ('e', 't', 4)]:
    G.ajouter_arc(u, v, c)

flot = {('s', 'a'): 2, ('s', 'b'): 2, ('a', 'd'): 1, ('a', 'c'): 1, ('b', 'c'): 1, ('b', 'e'): 1, ('c', 't'): 2,
        ('d', 't'): 1, ('e', 't'): 1}



# print(sorted(ensemble_minimum_augmentations_utiles_calibrees(G, flot, 1).items()))
# print(sorted(ensemble_minimum_augmentations_utiles_calibrees(G, flot, 3).items()))
# print(sorted(ensemble_minimum_augmentations_utiles_calibrees(G, flot, 4).items()))
print('interesting test :')
print(sorted(ensemble_minimum_augmentations_utiles_calibrees(G, flot, 5).items()))
#
# G = Graphe()
# for u, v, c in [('s', 'a', 4), ('s', 'b', 4), ('a', 'd', 1), ('a', 'c', 3), ('b', 'c', 3), ('b', 'e', 1), ('c', 't', 2),
#                 ('d', 't', 2), ('e', 't', 4)]:
#     G.ajouter_arc(u, v, c)
# flot = {('s', 'a'): 2, ('s', 'b'): 2, ('a', 'd'): 1, ('a', 'c'): 1, ('b', 'c'): 1, ('b', 'e'): 1, ('c', 't'): 2,
#         ('d', 't'): 1, ('e', 't'): 1}
# residuel = reseau_residuel(G, flot)
# print(tuple(map(sorted, coupe_minimum(residuel, G.sources()))))


print('=======================')

