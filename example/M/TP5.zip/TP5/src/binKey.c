/**
 * @author Marc AGNETTI
 * @create date 2021-11-12 17:38:08
 * @modify date 2021-11-18 17:47:42
 * @desc Source file for the binary key
 */


#include "../inc/binKey.h"


int generate_random_key(Bitkey* B){
    int i;
    
    if (B == NULL){
        return 1;
    }
    
    srand(time(NULL));
    for (i = 0 ; i < NB_OCT ; i++){
        B->values[i] = rand() % 256;
    }
    
    return 0;
}


int sort_bitkey(Bitkey* tab){
    int i, j;
    Bitkey key;
    for (i = 0 ; i < 8 - 1 ; i++){
        for (j = i + 1 ; j < 8 ; j++){
            if (fitness_key(&tab[i]) > fitness_key(&tab[j])){
                key = tab[i];
                tab[i] = tab[j];
                tab[j] = key;
            }
        }
    }
    return 0;
}


int merge_keys(Bitkey a, Bitkey b, Bitkey c, Bitkey* res){
    int i;
    
    for (i = 0 ; i < NB_OCT ; i++){
        res->values[i] = (a.values[i] & b.values[i]) 
                            | (a.values[i] & c.values[i]) 
                            | (b.values[i] & c.values[i]);
    }

    return 0;
}


int generate_generation_key(Bitkey* B, int d){
    Bitkey tab[8];
    int i, r;
    
    if (d == 0){
        generate_random_key(B);
        return 0;
    }
    
    for (i = 0 ; i < 8 ; i++){
        r = generate_generation_key(&tab[i], d - 1);
        if (r != 0){
            fprintf(stderr, "Error !\n");
        }
    }
    
    sort_bitkey(tab);
    merge_keys(tab[5], tab[6], tab[7], B);

    return 0;
}
