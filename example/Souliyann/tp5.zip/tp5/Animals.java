package tp5;

public interface Animals {

}
